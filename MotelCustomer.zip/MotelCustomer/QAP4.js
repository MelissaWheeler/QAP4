// Create a MotelCustomer object
const MotelCustomer = {
  name: 'John Doe',
  birthDate: '01/01/1990',
  gender: 'male',
  roomPreferences: ['double bed', 'non-smoking', 'ocean view'],
  paymentMethod: 'credit card',
  mailingAddress: {
    street: '123 Main Street',
    city: 'Anytown',
    state: 'CA',
    zipCode: '12345'
  },
  phoneNumber: '555-555-5555',
  checkInDate: '10/15/2021',
  checkOutDate: '10/20/2021',
  getAge: function() {
    const today = new Date();
    const birthDate = new Date(this.birthDate);
    const age = today.getFullYear() - birthDate.getFullYear();
    return age;
  },
  getDurationOfStay: function() {
    const checkIn = new Date(this.checkInDate);
    const checkOut = new Date(this.checkOutDate);
    const diffTime = Math.abs(checkOut - checkIn);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  },
  describeCustomer: function() {
    return `Name: ${this.name}, Age: ${this.getAge()}, Gender: ${this.gender}, Room Preferences: ${this.roomPreferences.join(', ')}, Payment Method: ${this.paymentMethod}, Address: ${this.mailingAddress.street}, ${this.mailingAddress.city}, ${this.mailingAddress.state}, ${this.mailingAddress.zipCode}, Phone Number: ${this.phoneNumber}, Check-In Date: ${this.checkInDate}, Check-Out Date: ${this.checkOutDate}, Duration of Stay: ${this.getDurationOfStay()} days.`;
  }
};

// Display customer information
const customerInfo = MotelCustomer.describeCustomer();
console.log(customerInfo);
